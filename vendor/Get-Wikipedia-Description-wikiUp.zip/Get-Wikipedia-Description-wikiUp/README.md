wikiUp
======

Get Wikipedia descriptions in tooltips.

[Demo](http://pmtarantino.github.com/wikiUp/)

Usage
-----

Include: jQuery.js, wikiUp.js and wikiUp.css

Then, call like this:

```html
<span data-wiki="Apple Inc.">Apple</span> was founded by <span data-wiki="Steve Jobs">Steve Jobs</span>.
```

Tooltip
-------

The CSS3 tooltips are created by [Horacio Bella](http://horaciobella.com/tooltips/).
